import { Component, OnInit } from '@angular/core';
import { RestApiService } from '../services/rest-api.service';
import { Router } from '@angular/router';
import { StorageService } from '../services/storage.service';
import { SimpleWebDriverClient } from 'blocking-proxy/built/lib/simple_webdriver_client';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.scss']
})
export class OrderListComponent implements OnInit {
  orderList;
  newText='siri';
  pages = [1, 2, 3, 4];

  constructor(private restapiservice : RestApiService, 
    private router: Router, private storageService: StorageService){

   }

  ngOnInit() {
    this.restapiservice.getOrderList().then(res =>{
      this.orderList=res;
      console.log(res);
    }).catch(err =>{
      console.log(err)
    });
  }

  openOrderList(order){
    console.log(order);
    this.storageService.setCurrentOrder(order);
    this.router.navigate(['details']);
  }
  acceptDate(data) {
    console.log(JSON.stringify(data));
  }
  getPageNumber(page) {
    console.log(page);
  }

}






