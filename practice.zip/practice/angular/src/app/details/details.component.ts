import { Component, OnInit } from '@angular/core';
import { StorageService } from '../services/storage.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})
export class DetailsComponent implements OnInit {
  order;

  constructor(private storageService: StorageService, private router: Router) { 

  }

  ngOnInit() {
    this.order = this.storageService.getCurrentOrder();
    if(this.order === undefined) {
        this.router.navigate(['home']);
    }
    console.log(this.order);
}


}
