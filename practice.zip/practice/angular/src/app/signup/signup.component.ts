import { Component, OnInit } from '@angular/core';
import { RestApiService } from '../services/rest-api.service';
import {Router} from '@angular/router'

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignUpComponent{

  email;
  password;
  repeatPassword;
  errorMessage;

  constructor(private restapiservice : RestApiService , private router:Router) { 
   
}

  signup(email,password,repeatPassword){
    if(this.restapiservice.signup(email,password,repeatPassword)){
      this.router.navigate(['home']);
      return;
    }
    this.errorMessage='invalid data';
  }

}
