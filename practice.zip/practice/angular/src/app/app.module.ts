import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { DetailsComponent } from './details/details.component';
import { LoginComponent } from './login/login.component';
import { OrderListComponent } from './order-list/order-list.component';
import { OrderComponent } from './order/order.component';
import { PaginationComponent } from './pagination/pagination.component';
import { SignUpComponent } from './signup/signup.component';
import {AppRoutingModule} from './app-routing.module';
import {RestApiService} from './services/rest-api.service';
import {StorageService} from './services/storage.service';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    DetailsComponent,
    LoginComponent,
    OrderListComponent,
    OrderComponent,
    PaginationComponent,
    SignUpComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [RestApiService,StorageService],
  bootstrap: [AppComponent]
})
export class AppModule { }
