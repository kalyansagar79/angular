import{Injectable} from '@angular/core';
import{HttpClient} from '@angular/common/http';
import { promise } from 'protractor';
import { LoginComponent } from '../login/login.component';

@Injectable()
    export class RestApiService{
        constructor(private http:HttpClient){
     }

     signup(email,password,repeatPassword):boolean{
         if (email === 'sagar@gmail.com' && password === 'siri' && repeatPassword === 'siri'){
             return true;
         }
         return false;
     }


     login(userName,password):boolean{
     if(userName === 'siri' && password === 'akila'){
         return true;
     }
     return false;
     }


     getOrderList(): Promise <any>{
       return this.http.get('/assets/mock-data.json').toPromise().then(res =>{
           return res;
       }).catch( err =>{
           return err;
       });
      
     }

    }



