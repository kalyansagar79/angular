import {Injectable} from '@angular/core';


@Injectable()
export class StorageService{
    currentOrder;
    setCurrentOrder(order){
        this.currentOrder = order;
   }
   getCurrentOrder() {
    return this.currentOrder;
}
}