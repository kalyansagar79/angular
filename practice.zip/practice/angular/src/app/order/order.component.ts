import { Component, OnInit, Input, Output , EventEmitter} from '@angular/core';
import { text } from '@angular/core/src/render3/instructions';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.scss']
})
export class OrderComponent implements OnInit {
  title = 'laundry';
  @Input() text;
  @Output() sendDate = new EventEmitter<any>();
  fromDate = new Date();
  toDate = new Date;

  constructor() {
  }

  ngOnInit() {
  }
  submitDateChange(fromDate, toDate) {
    this.sendDate.emit({'fromDate': fromDate, 'toDate': toDate});
    return;
  }
}
