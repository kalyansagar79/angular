import { Component, OnInit } from '@angular/core';
import { RestApiService } from '../services/rest-api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  userName;
  password;
  errorMessage;

  constructor(private restapiservice:RestApiService , private router:Router){
 }

 login(userName,password){
   if(this.restapiservice.login(userName,password)){
     this.router.navigate(['home']);
   }
 this.errorMessage="invalid data"
}  
}
