function contactclick(){
    document.getElementById('middleSection').innerHTML="CONTACT-CLICK";
}
function signinclick(){
    document.getElementById('middleSection').innerHTML="SIGN-IN-CLICK";
}
function signoutclick(){
    document.getElementById('middleSection').innerHTML="SIGN-OUT-CLICK";
}
function employeeclick(){
    document.getElementById('middleSection').innerHTML="EMPLOYEE-CLICK";
}
function studentclick(){
    document.getElementById('middleSection').innerHTML="STUDENT-CLICK";
}
function teacherclick(){
    document.getElementById('middleSection').innerHTML="TEACHER-CLICK";
}
function parentclick(){
    document.getElementById('middleSection').innerHTML="PARENT-CLICK";
}
function childclick(){
    document.getElementById('middleSection').innerHTML="CHILD-CLICK";
}
function aboutusclick(){
    document.getElementById('middleSection').innerHTML="ABOUT-US-CLICK";
}
function mapclick(){
    document.getElementById('middleSection').innerHTML="MAP-CLICK";
}