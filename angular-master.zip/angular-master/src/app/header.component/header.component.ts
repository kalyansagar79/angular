import { Component } from '@angular/core';
import { RestApiService } from '../services/rest-api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  title = '';
  constructor(private restApiService: RestApiService, private router: Router) {
  }
  logout() {
    this.router.navigate(['login']);
  }
}
