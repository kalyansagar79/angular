import {Component, OnInit} from '@angular/core';
import {RestApiService} from '../services/rest-api.service';
import {StorageService} from '../services/storage.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.scss']
})
export class OrderListComponent implements OnInit {
  title = 'laundry';
  orderList;
  pages = [1, 2, 3, 4];
  newText = 'Sidharth';

  constructor(private restService: RestApiService,
              private storageService: StorageService,
              private router: Router) {

  }

  ngOnInit() {
    this.restService.getOrderList().subscribe(res => {
      this.orderList = res;
    }, err => {
      console.log(err);
    });
  }

  getOrderList(page = 1) {
    this.restService.getOrderList(page).subscribe(res => {
      this.orderList = res;
    }, err => {
      console.log(err);
    });
  }

  openOrderList(order) {
    console.log(order);
    this.storageService.setCurrentOrder(order);
    this.router.navigate(['details']);
  }

  acceptDate(data) {
    console.log(data);
  }

  getPageNumber(page) {
    this.getOrderList(page);
  }
}
