import {Component} from '@angular/core';
import {RestApiService} from '../services/rest-api.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.scss']
})
export class SignUpComponent {
  firstName;
  lastName;
  email;
  password;
  confirmPassword;
  errorMessage = '';

  constructor(private restApiService: RestApiService, private router: Router) {
  }

  signup(firstName, lastName, email, password, confirmPassword) {
    this.restApiService.signup(firstName, lastName, email, password, confirmPassword).subscribe(res => {
      this.router.navigate(['home']);
    }, err => {
      this.errorMessage = 'invalid data';
    });
  }

}

