import {Component} from '@angular/core';
import {RestApiService} from '../services/rest-api.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  email;
  password;
  errorMessage = '';

  constructor(private restApiService: RestApiService, private router: Router) {
  }

  /* login and password*/

  /*authenticate (login , password) {
    if (this.restApiService.authenticate(login, password)) {
      this.router.navigate(['home']);
      return;
    }
    this.errorMessage = 'Invalid Username and Password';
  }
}*/


  /*api*/

  authenticate(login, password) {
    this.restApiService.authenticate(login, password).subscribe(res => {
      this.router.navigate(['home']);
    }, err => {
      this.errorMessage = 'Invalid Username and Password';
    });
  }


}


