import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

import {AppComponent} from './app.component';
import {LoginComponent} from './login.component/login.component';
import {HeaderComponent} from './header.component/header.component';
import {HomeComponent} from './home.component/home.component';
import {OrderComponent} from './order.component/order.component';
import {AppRoutingModule} from './app-routing.module';
import {OrderListComponent} from './order-list.component/order-list.componenet';
import {RestApiService} from './services/rest-api.service';
import {DetailsComponent} from './details.component/details.component';
import {SignUpComponent} from './sign-up.component/sign-up.component';
import {StorageService} from './services/storage.service';
import {DateRangeComponent} from './date-range.component/date-range.componenet';
import {PaginationComponent} from './pagination.component/pagination.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HeaderComponent,
    HomeComponent,
    OrderComponent,
    OrderListComponent,
    DetailsComponent,
    SignUpComponent,
    DateRangeComponent,
    PaginationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [RestApiService, StorageService],
  bootstrap: [AppComponent]
})
export class AppModule {
}
