import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';

@Component({
  selector: 'app-date-range',
  templateUrl: './date-range.component.html',
  styleUrls: ['./date-range.component.scss']
})
export class DateRangeComponent implements OnInit {
  title = 'laundry';
  @Input() text1;
  @Output() sendDate = new EventEmitter<any>();
  fromDate = new Date();
  toDate = new Date();
  newDate = new Date();

  constructor() {
  }

  ngOnInit() {
  }

  submitDateChange(fromDate, toDate) {
    this.sendDate.emit({'fromDate': fromDate, 'toDate': toDate});
    return;
  }

  dateChangeDisplay(date) {
    this.newDate = date;
  }
}
