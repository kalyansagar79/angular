import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class RestApiService {
  constructor(private http: HttpClient) {

  }

  authenticate(login, password): any {
    const body = new FormData();
    body.append('username', login);
    body.append('password', password);
    return this.http.post('http://019e9e57.ngrok.io/signin/', body);
    // return false;
  }

  /*authenticate(email , Password): boolean {
    if (email === 'sagar@gmail.com' && Password === '1234') {
      return true;
    }
    return false;
  }*/
  signup(firstName, lastName, email, password, confirmPassword): any {
    const body = new FormData();
    body.append('first_name', firstName);
    body.append('last_name', lastName);
    body.append('email', email);
    body.append('password', password);
    body.append('username', email);
    return this.http.post('http://019e9e57.ngrok.io/signup/', body);
    // return false;
  }


  /*signup(firstName, lastName, email, password, confirmPassword): Promise<any> {
    return this.http.post('http://demo2668124.mockable.io/signin', {'firstname': firstName, 'lastname' : lastName , 'email' : email, 'password': password , 'confirmpassword': confirmPassword})
   .toPromise().then(res => {
        console.log(res);
        return true;
      }).catch(err => {
        console.log(err);
      });
    // return false;
  }*/


  getOrderList(page = 1): any {
    console.log(page);
    return this.http.get('/assets/mock-data.json');
  }

}
